﻿namespace P01_StudentSystem.Data
{
    public class ConnectionConfiguration
    {
        public const string ConnectionString = @"Server=DESKTOP-KLIRQ5H\SQLEXPRESS;Database=StudentSystem;Integrated Security=true";
    }
}
