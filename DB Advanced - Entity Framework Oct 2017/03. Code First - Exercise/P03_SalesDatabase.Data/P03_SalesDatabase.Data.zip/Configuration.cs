﻿namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-KLIRQ5H\SQLEXPRESS;Database=Sales;Integrated Security=true;";
    }
}
