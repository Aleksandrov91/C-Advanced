﻿namespace P01_HospitalDatabase
{
    public class Configuration
    {
        public const string Connection = "Server=DESKTOP-KLIRQ5H\\SQLEXPRESS;Database=Hospital;Integrated Security = true;";
    }
}
