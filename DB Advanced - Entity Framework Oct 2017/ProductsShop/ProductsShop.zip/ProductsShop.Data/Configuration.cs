﻿namespace ProductsShop.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-KLIRQ5H\SQLEXPRESS;Database=ProductsShop;Integrated Security=true;";
    }
}
