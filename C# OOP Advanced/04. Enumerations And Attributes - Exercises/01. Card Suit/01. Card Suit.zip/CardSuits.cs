﻿namespace _01.Card_Suit
{
    public enum CardSuits
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
