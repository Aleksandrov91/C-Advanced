﻿namespace _03.Card_Power
{
    using System;

    public class Startup
    {
        public static void Main()
        {
            var input = Console.ReadLine();

            foreach (CardSuit cardSuit in Enum.GetValues(typeof(CardSuit)))
            {
                foreach (CardRank cardRank in Enum.GetValues(typeof(CardRank)))
                {
                    Console.WriteLine($"{cardRank} of {cardSuit}");
                }
            }
        }
    }
}
