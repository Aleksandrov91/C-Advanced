﻿namespace _04.Telephony
{
    public interface IBrowsable
    {
        void Browse(string webSite);
    }
}
