﻿namespace _09.Collection_Hierarchy.Interfaces
{
    public interface IAddCollection<T>
    {
        int Add(T element);
    }
}
