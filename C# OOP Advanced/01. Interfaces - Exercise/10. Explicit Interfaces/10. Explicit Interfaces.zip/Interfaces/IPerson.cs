﻿namespace _10.Explicit_Interfaces.Interfaces
{
    interface IPerson
    {
        string Name { get; }

        int Age { get; }

        string GetName();
    }
}
