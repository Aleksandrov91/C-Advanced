﻿namespace _07.Food_Shortage.Entities
{
    public interface IDweller
    {
        string Id { get; }
    }
}
