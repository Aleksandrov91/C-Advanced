﻿namespace _07.Food_Shortage.Entities
{
    public interface IPerson
    {
        string Name { get; }
    }
}
