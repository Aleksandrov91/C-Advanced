﻿namespace _06.Birthday_Celebrations.Entities
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
