﻿namespace _06.Birthday_Celebrations.Entities
{
    public interface IDweller
    {
        string Id { get; }
    }
}
