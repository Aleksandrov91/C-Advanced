﻿namespace _03.Ferrari
{
    public interface ICar
    {
        string Brakes();

        string Gas();
    }
}
