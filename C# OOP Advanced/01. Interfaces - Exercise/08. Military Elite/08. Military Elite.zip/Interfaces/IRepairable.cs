﻿namespace _08.Military_Elite.Interfaces
{
    public interface IRepairable
    {
        string PartName { get; }

        int HoursWorked { get; }
    }
}
