﻿namespace _08.Military_Elite.Entities.Utils
{
    using Interfaces;
    public class Repair : IRepairable
    {
        public Repair(string partName, int hoursWorked)
        {
            this.PartName = partName;
            this.HoursWorked = hoursWorked;
        }
        public string PartName { get; }
        public int HoursWorked { get; }

        public override string ToString()
        {
            //Part Name: <partName> Hours Worked: <hoursWorked>

            return $"Part Name: {this.PartName} Hours Worked: {this.HoursWorked}";
        }
    }
}
