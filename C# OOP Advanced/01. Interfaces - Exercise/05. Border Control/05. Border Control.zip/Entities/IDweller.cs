﻿namespace _05.Border_Control.Entities
{
    public interface IDweller
    {
        string Id { get; }
    }
}
