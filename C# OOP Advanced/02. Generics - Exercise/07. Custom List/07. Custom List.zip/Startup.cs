﻿namespace _07.Custom_List
{
    public class Startup
    {
        public static void Main()
        {
            var engine = new CommandInterpreter();
            engine.Run();
        }
    }
}
