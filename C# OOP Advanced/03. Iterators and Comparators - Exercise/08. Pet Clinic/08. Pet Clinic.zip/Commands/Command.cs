﻿namespace _08.Pet_Clinic.Commands
{
    public abstract class Command
    {
        public abstract void Execute();
    }
}