﻿namespace _08.Pet_Clinic
{
    public class CommandInterpreter
    {
        
    }
}