﻿namespace BashSoft
{
    public class StartUp
    {
        public static void Main()
        {
            InputReader.StartReadingCommands();
        }
    }
}
