﻿using System.Linq;
using System.Text;

public class TimeLimitRace : Race
{
    private int goldTime;

    public TimeLimitRace(int length, string route, int prizePool, int goldTime)
        : base(length, route, prizePool)
    {
        this.goldTime = goldTime;
    }

    protected override int GetPoints(Car car)
    {
        return this.Length * ((car.HorsePower / 100) * car.Acceleration);
    }

    public override string StartRace()
    {
        var driverResult = this.Participants.OrderByDescending(x => GetPoints(x)).FirstOrDefault();
        var driverPoints = GetPoints(driverResult);
        var wonPrice = 0;

        var sb = new StringBuilder();
        sb.AppendLine($"{this.Route} - {this.Length}");
        sb.AppendLine($"{driverResult.Brand} {driverResult.Model} - {driverPoints} s.");

        if (driverPoints <= goldTime)
        {
            wonPrice = this.PrizePool;
            sb.AppendLine($"Gold Time, ${wonPrice}.");

        }
        else if (driverPoints <= goldTime + 15)
        {
            wonPrice = (this.PrizePool * 50) / 100;
            sb.AppendLine($"Silver Time, ${wonPrice}.");
        }
        else
        {
            wonPrice = (this.PrizePool * 30) / 100;
            sb.AppendLine($"Bronze Time, ${wonPrice}.");
        }

        return sb.ToString();
    }
}
