﻿using System.Collections.Generic;

public class CarManager
{
    private Dictionary<int, Car> cars;
    private Dictionary<int, Race> races;
    private Garage garage;

    public CarManager()
    {
        this.cars = new Dictionary<int, Car>();
        this.races = new Dictionary<int, Race>();
        this.garage = new Garage();
    }

    public void Register(int id, string type, string brand, string model, int yearOfProduction, int horsepower,
        int acceleration, int suspension, int durability)
    {
        var car = CarFactory.CreateCar(type, brand, model, yearOfProduction, horsepower, acceleration, suspension,
            durability);

        this.cars[id] = car;
    }

    public string Check(int id)
    {
        return this.cars[id].ToString();
    }

    public void Open(int id, string type, int length, string route, int prizePool)
    {
        var race = RaceFactory.OpenRace(type, length, route, prizePool);

        this.races[id] = race;
    }

    public void Open(int id, string type, int length, string route, int prizePool, int special)
    {
        var race = RaceFactory.OpenSpecialRace(type, length, route, prizePool, special);

        this.races[id] = race;
    }

    public void Participate(int carId, int raceId)
    {
        if (races[raceId].GetType().Name == "TimeLimitRace" && races[raceId].Participants.Count == 1)
        {
            return;
        }

        if (!garage.IsParked(carId))
        {
            this.races[raceId].AddParticipant(cars[carId]);
        }
    }

    public string Start(int id)
    {
        if (races[id].Participants.Count == 0)
        {
            return "Cannot start the race with zero participants.";
        }

        var result = races[id].StartRace();
        races.Remove(id);
        return result;
    }

    public void Park(int id)
    {
        foreach (var race in races.Values)
        {
            if (race.Participants.Contains(cars[id]))
            {
                return;
            }
        }

        this.garage.ParkCar(id, cars[id]);
    }

    public void UnPark(int id)
    {
        this.garage.UnParkCar(id);
    }

    public void Tune(int tuneIndex, string addOn)
    {
        this.garage.TuneCars(tuneIndex, addOn);
    }
}
