﻿public class Startup
{
    public static void Main()
    {
        var commands = new Commands();
        commands.ReadCommands();
    }
}
