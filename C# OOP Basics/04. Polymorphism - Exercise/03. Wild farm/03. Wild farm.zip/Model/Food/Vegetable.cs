﻿namespace _03.Wild_farm.FoodModel
{
    using Model;

    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {
        }
    }
}
