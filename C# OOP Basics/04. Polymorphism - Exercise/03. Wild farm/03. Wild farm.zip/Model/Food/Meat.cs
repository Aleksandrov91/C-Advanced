﻿namespace _03.Wild_farm.FoodModel
{
    using Model;

    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {
        }
    }
}
